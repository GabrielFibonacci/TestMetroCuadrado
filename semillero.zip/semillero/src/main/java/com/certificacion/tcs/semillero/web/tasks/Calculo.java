package com.certificacion.tcs.semillero.web.tasks;

import org.apache.commons.compress.archivers.sevenz.CLI;

import com.certificacion.tcs.semillero.web.user_interfaces.CalculadoraPages;
import com.certificacion.tcs.semillero.web.utils.Salario;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.actions.Scroll;

public class Calculo implements Task {

	@Override
	public <T extends Actor> void performAs(T gabriel) {
		
		String valor="";
		valor =Salario.salario();
		gabriel.attemptsTo(Click.on(CalculadoraPages.INGRESOS_MENSUALES));
		gabriel.attemptsTo(Enter.theValue(valor).into(CalculadoraPages.INGRESOS_MENSUALES));
		
		
		String edad =gabriel.gaveAsThe("Edad");
	
	
		
		switch (edad) {
		case "5":
			gabriel.attemptsTo(Click.on(CalculadoraPages.CINCO_AÑOS));
			break;
			
		case "10":
			gabriel.attemptsTo(Click.on(CalculadoraPages.DIEZ_AÑOS));
			break;
		case "15":
			gabriel.attemptsTo(Click.on(CalculadoraPages.QUINCE_AÑOS));
			break;
		case "20":
			gabriel.attemptsTo(Click.on(CalculadoraPages.VEINTE_AÑOS));
			break;
		default:
			System.out.println("El plazo ingresado no Existe");
			break;
		}
		
//		gabriel.attemptsTo(Scroll.to(CalculadoraPages.CALCULA_CUOTAS));
//		gabriel.attemptsTo(Scroll.to(CalculadoraPages.CALCULA_CUOTAS));
//		gabriel.attemptsTo(Click.on(CalculadoraPages.CALCULA_CUOTAS));
		
	
		
	}

	public static Calculo unCreditoDeVivienda()	{
	return Tasks.instrumented(Calculo.class);
	}
	
}
