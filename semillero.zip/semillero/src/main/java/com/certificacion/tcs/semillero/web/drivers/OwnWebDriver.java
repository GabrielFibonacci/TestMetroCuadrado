package com.certificacion.tcs.semillero.web.drivers;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;


public class OwnWebDriver {


		private WebDriver driver;

		private static List<OwnWebDriver> listOwnWebDriver = new ArrayList<>();


		public static OwnWebDriver onBrowser() {
		
				ChromeOptions chromeOptions = new ChromeOptions();
				chromeOptions.addArguments("--start-maximized --ignore-certificate-errors --disable-infobars");
				listOwnWebDriver.add(new OwnWebDriver());
				listOwnWebDriver.get(listOwnWebDriver.size() - 1).driver = new ChromeDriver(chromeOptions);
				listOwnWebDriver.get(listOwnWebDriver.size() - 1).driver.manage().timeouts().implicitlyWait(20,
						TimeUnit.SECONDS);
				return listOwnWebDriver.get(listOwnWebDriver.size() - 1);
		}

		public WebDriver inURL(String url) {
			driver.get(url);
			return listOwnWebDriver.get(listOwnWebDriver.size() - 1).driver;
		}

		public static WebDriver getBrowser() {
			return listOwnWebDriver.get(listOwnWebDriver.size() - 1).driver;
		}

	}

