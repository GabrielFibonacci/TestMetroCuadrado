package com.certificacion.tcs.semillero.web.models;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Selenium extends Properties {

	private static final long serialVersionUID = 1L;

	public static Properties parameters() {
		Properties prop = new Properties();
		InputStream is;
		try {
			is = new FileInputStream("selenium.properties");
			prop.load(is);
		} catch (IOException e) {
			System.out.println(e.toString());
		}
		return prop;
	}

}