package com.certificacion.tcs.semillero.web.user_interfaces;

import net.serenitybdd.screenplay.targets.Target;

public class CalculadoraPages {
	
	public static final Target CALCULA_VALOR_CUOTAS = Target.the("Calcula el valor de las cuotas ")
			.locatedBy("/html/body/div[3]/div[2]/div/ul/li[2]/a");


public static final Target INGRESOS_MENSUALES = Target.the("Mensaje Calcula el valor de las cuotas ")
.locatedBy("/html/body/div[3]/div[2]/div/div/div[2]/div[1]/form/div[1]/input | //*[@id=\"tabcordion-body-2\"]/div/div[1]/form/div[1]/input");

public static final Target CALCULA_CUOTAS = Target.the("Mensaje Calcula el valor de las cuotas ")
.locatedBy("//*[@id='tabcordion-body-2']/div/div/div[1]/form/button | /html/body/div[3]/div[2]/div/div/div[1]/div[1]/form/button");


public static final Target RESPUESTA_INGRESOS_MENSUALES = Target.the("Mensaje de Respuesta ingresos mensuales ")
.locatedBy("//*[@id='tabcordion-body-2']/div/div[3]/div[1]/dl[1]/dd");

public static final Target RESPUESTA_DEBES_TENER_INGRESOS = Target.the("Mensaje ingresos que debes tener ")
.locatedBy("//*[@id='tabcordion-body-2']/div/div[3]/div[1]/dl[2]/dd");

public static final Target RESPUESTA_INICIAL_MINIMA = Target.the("Mensaje cuota inicial minima ")
.locatedBy("/html/body/div[3]/div[2]/div/div/div[2]/div[3]/div[1]/dl[3]/dd");

public static final Target RESPUESTA_COMPRAR_INMUEBLE = Target.the("Mensaje plata que le prestan para inmueble ")
.locatedBy("/html/body/div[3]/div[2]/div/div/div[2]/div[3]/div[1]/dl[4]/dd");

//AÑOS

public static final Target CINCO_AÑOS = Target.the("Cinco años")
.locatedBy("/html/body/div[3]/div[2]/div/div/div[2]/div[1]/form/div[2]/select/option[1]");

public static final Target DIEZ_AÑOS = Target.the("Diez años")
.locatedBy("/html/body/div[3]/div[2]/div/div/div[2]/div[1]/form/div[2]/select/option[2]");

public static final Target QUINCE_AÑOS = Target.the("Quince años")
.locatedBy("/html/body/div[3]/div[2]/div/div/div[2]/div[1]/form/div[2]/select/option[3]");

public static final Target VEINTE_AÑOS = Target.the("Veinte años")
.locatedBy("/html/body/div[3]/div[2]/div/div/div[2]/div[1]/form/div[2]/select/option[4]");

}

