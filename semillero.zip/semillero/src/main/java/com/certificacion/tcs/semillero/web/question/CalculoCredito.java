package com.certificacion.tcs.semillero.web.question;

import com.certificacion.tcs.semillero.web.user_interfaces.CalculadoraPages;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class CalculoCredito implements Question<Boolean> {

	@Override
	public Boolean answeredBy(Actor gabriel) {

		CalculadoraPages.RESPUESTA_INGRESOS_MENSUALES.resolveFor(gabriel).isVisible();

		CalculadoraPages.RESPUESTA_INICIAL_MINIMA.resolveFor(gabriel).isVisible();

		CalculadoraPages.RESPUESTA_COMPRAR_INMUEBLE.resolveFor(gabriel).isVisible();

		return true;
	}

	public static CalculoCredito enLaPagina() {
		return new CalculoCredito();
	}
}
