package com.certificacion.tcs.semillero.web.interactions;

import com.certificacion.tcs.semillero.web.user_interfaces.CalculadoraPages;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;

public class Calculadora  implements Interaction {

	@Override
	public <T extends Actor> void performAs(T gabriel) {
		CalculadoraPages.CALCULA_VALOR_CUOTAS.resolveFor(gabriel).isPresent();
		gabriel.attemptsTo(Click.on(CalculadoraPages.CALCULA_VALOR_CUOTAS));
	
		
		
	}
	public static Calculadora deCreditos() {
		return Tasks.instrumented(Calculadora.class);
	}

}
