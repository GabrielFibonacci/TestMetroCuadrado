package com.certificacion.tcs.semillero.web.utils;

import java.util.Random;

public class Salario {

	public static String salario() {
		int min=20000000; int max=30000000;
		int salario=0;
		String sueldo ="";
		Random r = new Random();
		salario= r.nextInt((max - min) + 1) + min;
		
		sueldo=Integer.toString(salario);
		
		return sueldo;
		
		
		
		
	}
}
