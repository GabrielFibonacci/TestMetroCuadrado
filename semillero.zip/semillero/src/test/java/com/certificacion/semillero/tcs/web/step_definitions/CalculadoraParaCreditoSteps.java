package com.certificacion.semillero.tcs.web.step_definitions;

import static net.serenitybdd.screenplay.actors.OnStage.setTheStage;
import static net.serenitybdd.screenplay.actors.OnStage.theActorCalled;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;

import java.awt.List;
import java.nio.channels.SeekableByteChannel;

import com.certificacion.tcs.semillero.web.interactions.Calculadora;
import com.certificacion.tcs.semillero.web.models.Cliente;
import com.certificacion.tcs.semillero.web.question.CalculoCredito;
import com.certificacion.tcs.semillero.web.tasks.Calculo;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.screenplay.GivenWhenThen;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actors.Cast;
import net.serenitybdd.screenplay.actors.OnStage;

public class CalculadoraParaCreditoSteps {
	
	@Before
	public void init() {
		setTheStage(Cast.ofStandardActors());
		theActorCalled("Gabriel");
		
		theActorInTheSpotlight()
			.can(BrowseTheWeb.with(com.certificacion.tcs.semillero.web.drivers.OwnWebDriver.onBrowser().inURL(com.certificacion.tcs.semillero.web.models.Selenium.parameters().getProperty("url"))));

	}
	
	@Given("^que me autentico en la pagina$")
	public void queMeAutenticoEnLaPagina() {
		OnStage.theActorInTheSpotlight().attemptsTo(Calculadora.deCreditos());
	}


	@When("^digito el ingreso mensual y los (\\d+) años del plazo$")
	public void digitoElIngresoMensualYLosAñosDelPlazo(String años) {
		
		OnStage.theActorInTheSpotlight().remember("Edad", años);
		OnStage.theActorInTheSpotlight().attemptsTo(Calculo.unCreditoDeVivienda());
	 
	}

	@Then("^verifico la Respuesta de la solicitud de credito$")
	public void verificoLaRespuestaDeLaSolicitudDeCredito() {
	  OnStage.theActorInTheSpotlight().should(GivenWhenThen.seeThat(CalculoCredito.enLaPagina()));
	}

	@Then("^verifico la Respuesta de la solicitud de credito con un saldo inferior$")
	public void verificoLaRespuestaDeLaSolicitudDeCreditoConUnSaldoInferior() {
	   
	}
	
	@When("^digito el ingreso mensual y los años del plazo$")
	public void digitoElIngresoMensualYLosAñosDelPlazo() {
	   
	}




}
